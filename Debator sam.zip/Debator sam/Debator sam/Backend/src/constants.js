export const DB_NAME = "vox_debate";
