import React from "react";

const Blogs = () => {
  return (
    <div className="flex justify-center items-center h-[45rem] w-full ">
    
    </div>
  );
};

export default Blogs;
