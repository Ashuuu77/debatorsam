import Hero from "./Hero";
import Login from "./Login";
import Manual from "./Manual";
import Playground from "./Playground";
import Signup from "./Signup";
import About from "./About";
import Testimonials from "./Testimonials";
import Blogs from "./Blogs";

export { Hero, Login, Manual, Playground, Signup, About, Testimonials, Blogs };
